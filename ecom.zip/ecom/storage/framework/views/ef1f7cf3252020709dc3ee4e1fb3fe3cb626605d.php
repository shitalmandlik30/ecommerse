<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Edit Child SubCategory
                    <a href="<?php echo e(route('subcategories.create')); ?>" class="btn btn-primary float-right">Create  Child SubCategory</a>
                </div>

                <div class="card-body">
                    
                    <form action="<?php echo e(route('childsubcategories.update', ['childsubcategory'=>$childsubcategory->id] )); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="PUT">
                        <div class="form-group">
                            <label for="name">Child SubCategory Name:</label>
                            <input type="name" class="form-control" id="name" name="name" value="<?php echo e($childsubcategory->childsubcatename); ?>">
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="pwd">Category Name :</label>
                            <select class="form-control" name="subcategory_id">
                                <option>Select a SubCategory</option>
                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->subcategoryname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php echo e($errors->first('parent_category')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="pwd">Category Name :</label>
                            <select class="form-control" name="category_id">
                                <option>Select a category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php echo e($errors->first('parent_category')); ?></span>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/ecom/resources/views/childsubcategories/edit.blade.php ENDPATH**/ ?>