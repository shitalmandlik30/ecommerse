<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Edit Product
                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary float-right">Add Product</a>
                </div>

                <div class="card-body">
                    
                    <form action="<?php echo e(route('products.update', ['product' => $product->id] )); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="PUT">
                        <div class="form-group">
                            <label for="name">Product Name:</label>
                            <input type="name" class="form-control" id="name" name="name" value="<?php echo e($product->name); ?>" required>
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="name">Product Description:</label>
                            <input type="name" class="form-control" id="name" name="description" value="<?php echo e($product->description); ?>" required>
                            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                        </div>


                        <div class="form-group">
                            <label for="name">Actual Price:</label>
                            <input type="number" class="form-control" id="name" name="actualprice" value="<?php echo e($product->actual_price); ?>" required>
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        </div>


                        <div class="form-group">
                            <label for="name">Discount :</label>
                            <input type="number" class="form-control" id="name" name="discount" value="<?php echo e($product->discount); ?>">
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="pwd">Category Name :</label>
                            <select class="form-control" name="category_id" required>
                                <option>Select a category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php echo e($errors->first('parent_category')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="pwd">Sub Category Name :</label>
                            <select class="form-control" name="subcategory_id" required>
                                <option>Select a SubCategory</option>
                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->subcategoryname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php echo e($errors->first('parent_category')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="pwd">Child Sub Category Name :</label>
                            <select class="form-control" name="childsubcategory_id" required>
                                <option>Select a Child SubCategory</option>
                                <?php $__currentLoopData = $childsubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->childsubcatename); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php echo e($errors->first('parent_category')); ?></span>
                        </div>
                       
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/ecom/resources/views/products/edit.blade.php ENDPATH**/ ?>