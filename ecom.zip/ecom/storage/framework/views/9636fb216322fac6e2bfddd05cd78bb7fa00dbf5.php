<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Products
                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary float-right">Add Products</a>
                </div>

                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Product Description</th>
                                <!-- <th>Color</th> -->
                                <th>Actual Price</th>
                                <th>Discount</th>
                                <th>Category Name</th>
                                <th>Sub Category Name</th>
                                <th>Child Sub Category Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($category->name); ?></td>
                                <td><?php echo e($category->description); ?></td>
                                <!-- <td><?php echo e($category->color); ?></td> -->
                                <td><?php echo e($category->actual_price); ?></td>
                                <td><?php echo e($category->discount); ?></td>
                                <td>
                                    <?php if($category->category): ?>
                                        <?php echo e($category->category->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($category->subcategory): ?>
                                        <?php echo e($category->subcategory->subcategoryname); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($category->childsubcategory): ?>
                                        <?php echo e($category->childsubcategory->childsubcatename); ?>

                                    <?php endif; ?>
                                </td>
                               
                                <td>
                                    <a href="<?php echo e(route('products.edit', ['product'=> $category->id])); ?>" class="btn btn-xs btn-info">Edit</a>
                                    <form action="<?php echo e(route('products.destroy', ['product'=> $category->id])); ?>" method="POST" style="display: inline-block;">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-xs btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/ecom/resources/views/products/index.blade.php ENDPATH**/ ?>