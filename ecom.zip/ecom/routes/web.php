<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Dashboard;
use App\Http\Controllers\SubCategoryController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/
Route::get('/', [Dashboard::class,'index']);
Route::resource('/categories', 'App\Http\Controllers\CategoryController');
Route::resource('/subcategories', 'App\Http\Controllers\SubCategoryController');
Route::resource('/childsubcategories', 'App\Http\Controllers\ChildSubCategoryController');
Route::resource('/products', 'App\Http\Controllers\Products');
