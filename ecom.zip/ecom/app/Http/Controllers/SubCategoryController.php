<?php

namespace App\Http\Controllers;

use App\Models\SubCategory;
use App\Models\Category;
use Illuminate\Http\Request;

class SubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        // dd('hi');
        $subcategories = SubCategory::all();
        return view('subcategories.index')->with(compact(['subcategories']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        return view('subcategories.create')->with(compact(['categories']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $subcategory = new SubCategory;
        $subcategory->subcategoryname = $request->name;
        $subcategory->category_id = $request->category_id ? $request->category_id : 0;

        if ($subcategory->save() ) {
            return redirect()->route('subcategories.index')->with(['success' => 'SubCategory added successfully.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to add SubCategory.']);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(SubCategory $subcategory)
    {
        $categories = Category::all();
        return view('subcategories.edit')->with(['subcategory'=>$subcategory,'categories' =>$categories]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SubCategory $subcategory)
    {
        $subcategory->subcategoryname = $request->name;
        $subcategory->category_id = $request->category_id ? $request->category_id : 0;

        if ($subcategory->save() ) {
            return redirect()->route('subcategories.index')->with(['success' => 'SubCategory successfully updated.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to update SubCategory.']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(SubCategory $subcategory)
    {
        if ($subcategory->delete()) {
            return redirect()->back()->with(['success' => 'SubCategory successfully deleted.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to delete SubCategory.']);
    }
}