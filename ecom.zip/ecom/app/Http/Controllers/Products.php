<?php

namespace App\Http\Controllers;

use App\Models\ChildSubCategory;
use App\Models\Category;
use App\Models\Product;
use App\Models\SubCategory;
use Illuminate\Http\Request;

class Products extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        // dd('hi');
        $products = Product::all();
        return view('products.index')->with(compact(['products']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        $subcategories = SubCategory::all();
        $childsubcategories = ChildSubCategory::all();

        return view('products.create')->with(['categories' => $categories,'subcategories'=>$subcategories,"childsubcategories"=>$childsubcategories]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $products = new Product();
        $products->name = $request->name;
        $products->description = $request->desc ? $request->desc : '';
        //$products->color = $request->color ? $request->color : 0;
        $products->actual_price = $request->actualprice ? $request->actualprice : 0;
        $products->discount = $request->discount ? $request->discount : 0;
        $products->category_id = $request->category_id ? $request->category_id : 0;
        $products->subcategory_id = $request->subcategory_id ? $request->subcategory_id : 0;
        $products->childcategory_id = $request->childsubcategory_id ? $request->childsubcategory_id : 0;
        $products->sku = $request->childsubcate_id ? $request->childsubcate_id : 0;


        if ($products->save() ) {
            return redirect()->route('products.index')->with(['success' => 'Products added successfully.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to add Products']);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        $categories = Category::all();
        $subcategories = SubCategory::all();
        $childsubcategories = ChildSubCategory::all();
        return view('products.edit')->with([
        'product'=>$product,
        'categories'=>$categories,
        'subcategories'=>$subcategories,
        'childsubcategories' =>$childsubcategories]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        $product->name = $request->name;
        $product->category_id = $request->category_id ? $request->category_id : 0;
        $product->subcategory_id = $request->subcategory_id ? $request->subcategory_id : 0;
        $product->childcategory_id = $request->childsubcategory_id ? $request->childsubcategory_id : 0;
        $product->description = $request->description ? $request->description : '';
        $product->actual_price = $request->actualprice ? $request->actualprice : 0;
        $product->discount = $request->discount ? $request->discount : 0;
        $product->sku = 0;//$request->childsubcate_id ? $request->childsubcate_id : 0;

        if ($product->update()) {
            return redirect()->route('products.index')->with(['success' => 'Product successfully updated.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to update Product.']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        if ($product->delete()) {
            return redirect()->back()->with(['success' => 'Product successfully deleted.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to delete Product.']);
    }
}