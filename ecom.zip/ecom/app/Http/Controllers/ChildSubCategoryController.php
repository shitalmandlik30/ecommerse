<?php

namespace App\Http\Controllers;

use App\Models\ChildSubCategory;
use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Http\Request;

class ChildSubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        // dd('hi');
        $childsubcategories = ChildSubCategory::all();
        return view('childsubcategories.index')->with(compact(['childsubcategories']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        $subcategories = SubCategory::all();
        return view('childsubcategories.create')->with(['categories' => $categories,'subcategories'=>$subcategories]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $subcategory = new ChildSubCategory;
        $subcategory->childsubcatename = $request->name;
        $subcategory->category_id = $request->category_id ? $request->category_id : 0;
        $subcategory->subcategory_id = $request->subcategory_id ? $request->subcategory_id : 0;

        if ($subcategory->save() ) {
            return redirect()->route('childsubcategories.index')->with(['success' => 'Child SubCategory added successfully.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to add Child SubCategory.']);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(ChildSubCategory $childsubcategory)
    {
        $categories = Category::all();
        $subcategories = SubCategory::all();
        return view('childsubcategories.edit')->with(['childsubcategory'=>$childsubcategory,
        'subcategories'=>$subcategories,
        'categories' =>$categories]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ChildSubCategory $subcategory)
    {
        $subcategory->childsubcatename = $request->name;
        $subcategory->category_id = $request->category_id ? $request->category_id : 0;
        $subcategory->subcategory_id = $request->subcategory_id ? $request->subcategory_id : 0;

        if ($subcategory->update() ) {
            return redirect()->route('childsubcategories.index')->with(['success' => 'Child SubCategory successfully updated.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to update Child SubCategory.']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(ChildSubCategory $childsubcategory)
    {
        if ($childsubcategory->delete()) {
            return redirect()->back()->with(['success' => 'SubCategory successfully deleted.']);
        }

        return redirect()->back()->with(['fail' => 'Unable to delete SubCategory.']);
    }
}