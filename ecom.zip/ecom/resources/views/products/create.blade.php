@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Add Products
                    <a href="{{ route('products.create') }}" class="btn btn-primary float-right">Add Products</a>
                </div>

                <div class="card-body">
                    
                    <form action="{{ route('products.store') }}" method="post">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <label for="parent_category">Category Name:</label>
                            <select class="form-control" name="category_id" required>
                                <option value="">Select a category</option>
                                @foreach($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                            <span class="text-danger">{{ $errors->first('parent_category') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="parent_category">Sub Category Name:</label>
                            <select class="form-control" name="subcategory_id" required>
                                <option value="">Select a SubCategory</option>
                                @foreach($subcategories as $category)
                                <option value="{{ $category->id }}">{{ $category->subcategoryname }}</option>
                                @endforeach
                            </select>
                            <span class="text-danger">{{ $errors->first('parent_category') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="parent_category">Child SubCategory Name:</label>
                            <select class="form-control" name="childsubcategory_id" required>
                                <option value="">Select a Child SubCategory</option>
                                @foreach($childsubcategories as $category)
                                <option value="{{ $category->id }}">{{ $category->childsubcatename }}</option>
                                @endforeach
                            </select>
                            <span class="text-danger">{{ $errors->first('parent_category') }}</span>
                        </div>


                        <div class="form-group">
                            <label for="name">Product Name:</label>
                            <input type="name" class="form-control" id="name" placeholder="Enter name" name="name" required>
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="name">Actual Price</label>
                            <input type="number" class="form-control" id="name" placeholder="Enter Actual name" name="actualprice" required>
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="name">Discount</label>
                            <input type="number" class="form-control" id="name" placeholder="Enter Discount" name="discount" required>
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="name">Product Description:</label>
                            <textarea type="name" class="form-control" id="name" placeholder="Enter Description" name="desc" required></textarea>
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        </div>

                       
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection