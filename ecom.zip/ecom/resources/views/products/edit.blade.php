@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Edit Product
                    <a href="{{ route('products.create') }}" class="btn btn-primary float-right">Add Product</a>
                </div>

                <div class="card-body">
                    
                    <form action="{{ route('products.update', ['product' => $product->id] ) }}" method="post">
                        {{ csrf_field() }}
                        <input name="_method" type="hidden" value="PUT">
                        <div class="form-group">
                            <label for="name">Product Name:</label>
                            <input type="name" class="form-control" id="name" name="name" value="{{ $product->name }}" required>
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="name">Product Description:</label>
                            <input type="name" class="form-control" id="name" name="description" value="{{ $product->description }}" required>
                            <span class="text-danger">{{ $errors->first('description') }}</span>
                        </div>


                        <div class="form-group">
                            <label for="name">Actual Price:</label>
                            <input type="number" class="form-control" id="name" name="actualprice" value="{{ $product->actual_price }}" required>
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        </div>


                        <div class="form-group">
                            <label for="name">Discount :</label>
                            <input type="number" class="form-control" id="name" name="discount" value="{{ $product->discount }}">
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="pwd">Category Name :</label>
                            <select class="form-control" name="category_id" required>
                                <option>Select a category</option>
                                @foreach($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                            <span class="text-danger">{{ $errors->first('parent_category') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="pwd">Sub Category Name :</label>
                            <select class="form-control" name="subcategory_id" required>
                                <option>Select a SubCategory</option>
                                @foreach($subcategories as $category)
                                <option value="{{ $category->id }}">{{ $category->subcategoryname }}</option>
                                @endforeach
                            </select>
                            <span class="text-danger">{{ $errors->first('parent_category') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="pwd">Child Sub Category Name :</label>
                            <select class="form-control" name="childsubcategory_id" required>
                                <option>Select a Child SubCategory</option>
                                @foreach($childsubcategories as $category)
                                <option value="{{ $category->id }}">{{ $category->childsubcatename }}</option>
                                @endforeach
                            </select>
                            <span class="text-danger">{{ $errors->first('parent_category') }}</span>
                        </div>
                       
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection