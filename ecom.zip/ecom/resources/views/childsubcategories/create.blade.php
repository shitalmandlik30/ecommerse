@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Create Child SubCategory
                    <a href="{{ route('childsubcategories.create') }}" class="btn btn-primary float-right">Create Child SubCategory</a>
                </div>

                <div class="card-body">
                    
                    <form action="{{ route('childsubcategories.store') }}" method="post">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <label for="name">Child SubCategory Name:</label>
                            <input type="name" class="form-control" id="name" placeholder="Enter name" name="name">
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="parent_category">Category Name:</label>
                            <select class="form-control" name="category_id">
                                <option value="">Select a category</option>
                                @foreach($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                            <span class="text-danger">{{ $errors->first('parent_category') }}</span>
                        </div>

                        <div class="form-group">
                            <label for="parent_category">Sub Category Name:</label>
                            <select class="form-control" name="subcategory_id">
                                <option value="">Select a SubCategory</option>
                                @foreach($subcategories as $category)
                                <option value="{{ $category->id }}">{{ $category->subcategoryname }}</option>
                                @endforeach
                            </select>
                            <span class="text-danger">{{ $errors->first('parent_category') }}</span>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection