@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Child Sub Categories
                    <a href="{{ route('childsubcategories.create') }}" class="btn btn-primary float-right">Create Child Sub Category</a>
                </div>

                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Child Sub Category Name</th>
                                <th>Sub Category Name</th>
                                <th>Category Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($childsubcategories as $category)
                            <tr>
                                <td>{{ $category->childsubcatename}}</td>
                                <td>
                                    @if ($category->subcategory)
                                        {{ $category->subcategory->subcategoryname}}
                                    @endif
                                </td>
                                <td>
                                    @if ($category->category)
                                        {{ $category->category->name}}
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('childsubcategories.edit', ['childsubcategory'=> $category->id]) }}" class="btn btn-xs btn-info">Edit</a>
                                    <form action="{{ route('childsubcategories.destroy', ['childsubcategory'=> $category->id]) }}" method="POST" style="display: inline-block;">
                                        @method('DELETE')
                                        @csrf
                                        <button class="btn btn-xs btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection